import Answer3.network as network
import utils
import numpy as np
import torch


class cfg:
    batch_size = 10
    epochs = 10
    iters_per_epochs = 1000
    lr = 1e-4
    train_data_path = "train_data.txt"
    train_label_path = "train_truth.txt"
    net = network.MLP().cuda()
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)


def data_read(path):
    data = utils.read_txt(path)
    data = utils.split_data(data)
    keys = data.keys()
    out = []
    for key in keys:
        out.append(np.expand_dims(np.array(data[key]), axis=1))
    return np.concatenate(out, axis=1)

def data_loader(data, batch_size=10, max_iter = 1000000):
    length = data.shape[0]
    start = 0
    end = start + batch_size
    for i in range(max_iter):
        indexes = range(start, end)
        indexes = np.array(indexes)
        indexes = indexes % length
        start += batch_size
        start = start % length
        end = start + batch_size
        yield data[indexes, :]


def train():
    data = data_read(cfg.train_data_path)
    label = data_read(cfg.train_label_path)
    inputs = data_loader(data, cfg.batch_size)
    labels = data_loader(label, cfg.batch_size)
    net = cfg.net
    loss_func = torch.nn.functional.smooth_l1_loss
    optimizer = cfg.optimizer
    for i in range(cfg.epochs):
        print('------------------------------')
        for j in range(cfg.iters_per_epochs):
            optimizer.zero_grad()
            input = torch.tensor(next(inputs), dtype=torch.float32).cuda()
            label = torch.tensor(next(labels), dtype=torch.float32).cuda()
            pred = net(input)
            loss = 0
            loss += loss_func(pred, label)
            print('iter/epoch : {}/{}, loss = {}'.format(j, i, loss.data))
            loss.backward()
            optimizer.step()
    torch.save(net.state_dict(), "params.pkl")
    return 0


if __name__ == '__main__':
    train()

