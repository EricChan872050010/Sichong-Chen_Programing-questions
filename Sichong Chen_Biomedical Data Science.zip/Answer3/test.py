import Answer3.network as network
import utils
import numpy as np
import torch


class cfg:
    batch_size = 1
    epochs = 1
    iters_per_epochs = 2500
    test_data_path = "test_data.txt"
    save_path = "test_predicted.txt"
    net = network.MLP().cuda()
    params_path = "params.pkl"


def data_read(path):
    data = utils.read_txt(path)
    data = utils.split_data(data)
    keys = data.keys()
    out = []
    for key in keys:
        out.append(np.expand_dims(np.array(data[key]), axis=1))
    return np.concatenate(out, axis=1)

def data_loader(data, batch_size=10, max_iter = 1000000):
    length = data.shape[0]
    start = 0
    end = start + batch_size
    for i in range(max_iter):
        indexes = range(start, end)
        indexes = np.array(indexes)
        indexes = indexes % length
        start += batch_size
        start = start % length
        end = start + batch_size
        yield data[indexes, :]

def test():
    data = data_read(cfg.test_data_path)
    inputs = data_loader(data, cfg.batch_size)
    net = cfg.net
    net.load_state_dict(torch.load(cfg.params_path))
    preds = []
    for i in range(cfg.epochs):
        print('------------------------------')
        for j in range(cfg.iters_per_epochs):
            with torch.no_grad():
                input = torch.tensor(next(inputs), dtype=torch.float32).cuda()
                pred = net(input)
                preds.append(pred[0, 0].cpu().numpy())
                print('iter/epoch : {}/{}'.format(j, i))
    utils.write_txt(cfg.save_path, preds)
    return 0


if __name__ == '__main__':
    test()
