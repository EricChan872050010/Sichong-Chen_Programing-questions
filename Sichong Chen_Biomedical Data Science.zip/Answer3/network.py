import torch.nn as nn


class MLP(nn.Module):
    def __init__(self, input_nums=3, output_nums=1, hidden_nums=[4, 4]):
        super(MLP, self).__init__()
        self.input_nums = input_nums
        self.output_nums = output_nums
        self.hidden_nums = hidden_nums
        self.inp_layer = nn.Linear(in_features=self.input_nums, out_features=self.hidden_nums[0], bias=True)
        self.hidden_layer = nn.Linear(in_features=self.hidden_nums[0], out_features=self.hidden_nums[1], bias=True)
        self.out_layer = nn.Linear(in_features=self.hidden_nums[1], out_features=self.output_nums, bias=True)

    def forward(self, input):
        out = self.inp_layer(input)
        out = self.hidden_layer(out)
        out = self.out_layer(out)
        return out

