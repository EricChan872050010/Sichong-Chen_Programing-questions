import numpy as np
import utils


def get_points_coors(matrix):
    x, y = np.nonzero(matrix)
    x = np.expand_dims(x, axis=1)
    y = np.expand_dims(y, axis=1)
    return np.concatenate([x, y], axis=1)

def compute_distance(component, else_component):
    num_component = component.shape[0]
    num_else_component = else_component.shape[0]
    component_expand = np.expand_dims(component, axis=1)
    else_conponent_expand = np.expand_dims(else_component, axis=0)
    component_expand = np.repeat(component_expand, repeats=num_else_component, axis=1)
    else_conponent_expand = np.repeat(else_conponent_expand, repeats=num_component, axis=0)
    distance = np.sum((component_expand - else_conponent_expand) ** 2, axis=2) ** 0.5
    return distance

def judge_is_end(component, else_component, threthold):
    if else_component.shape[0] == 0:
        return True
    else:
        distance = compute_distance(component, else_component)
        if np.min(distance) > threthold:
            return True
        else:
            return False

def iteration(component, else_component, threthold):
    distance = compute_distance(component, else_component)
    distance = np.min(distance, axis=0, keepdims=False)
    distance = distance < threthold
    part = else_component[distance]
    distance = (1 - distance.astype(int)).astype(bool)
    else_component = else_component[distance]
    component = np.concatenate([component, part], axis=0)
    return component, else_component

def find(matrix, mode='4_connectivity'):
    threthold_dict = {'4_connectivity': 1.1, '8_connectivity': 1.6}
    threthold = threthold_dict[mode]
    else_component = get_points_coors(matrix)
    components = []
    for i in range(1000):
        if else_component.shape[0] == 0:
            break
        component = else_component[:1, :]
        else_component = else_component[1:, :]
        for j in range(1000):
            if judge_is_end(component, else_component, threthold):
                break
            else:
                component, else_component = iteration(component, else_component, threthold)
        components.append(component)
    return components

def draw_matrix(matrix, components):
    matrix[:, :] = 0
    for i, component in enumerate(components):
        matrix[component[:, 0], component[:, 1]] = i + 1
    return matrix


# matrix = np.array([[0, 0, 1, 1],
#                    [1, 1, 0, 0],
#                    [0, 0, 0, 0],
#                    [0, 1, 1, 0],
#                    [0, 1, 1, 1]])
# components = find(matrix, mode='4_connectivity')
# matrix = draw_matrix(matrix, components)
# print(matrix)
# print('------------------------------')
# matrix = np.array([[0, 0, 1, 1],
#                    [1, 1, 0, 0],
#                    [0, 0, 0, 0],
#                    [0, 1, 1, 0],
#                    [0, 1, 1, 1]])
# components = find(matrix, mode='8_connectivity')
# matrix = draw_matrix(matrix, components)
# print(matrix)

def main():
    data = utils.read_txt("input_question_4")
    data = utils.split_matrix(data)
    data = np.array(data)
    print("input data is :")
    print(data)
    print("-----------------------")
    matrix = data
    components = find(matrix, mode='8_connectivity')
    matrix = draw_matrix(matrix, components).astype(int)
    print("mode is 8_connectivity, the output is :")
    print(matrix)
    draw_context = []
    for i in range(matrix.shape[0]):
        context = "\t".join([str(val) for val in matrix[i, :].tolist()])
        draw_context.append(context)
    utils.write_txt("output_question_4_8connectivity", draw_context, head=None)
    print("-----------------------")
    matrix = data
    components = find(matrix, mode='4_connectivity')
    matrix = draw_matrix(matrix, components).astype(int)
    print("mode is 4_connectivity, the output is :")
    print(matrix)
    draw_context = []
    for i in range(matrix.shape[0]):
        context = "\t".join([str(val) for val in matrix[i, :].tolist()])
        draw_context.append(context)
    utils.write_txt("output_question_4_4connectivity", draw_context, head=None)
    print("-----------------------")
    return 0

if __name__ == "__main__":
    main()
