
import numpy as np

def DirectTo(matrix,total):
    num=total-1
    columns=0
    rows=0
    path=str()
    if num>TotalValue(matrix,rows,columns)[1] or num<TotalValue(matrix,rows,columns)[0]:
        return(str(total)+" "+"Error")
    
    else:
        next=matrix.shape[0]+matrix.shape[1]-1
        for q in range(0,next-1):
            Rtotal=TotalValue(matrix,rows,columns)[0]
            Dtotal=TotalValue(matrix,rows,columns)[1]
        if abs(Rtotal-num)<=abs(Dtotal-num):

            columns=columns+1

            if columns==matrix.shape[1]-1 and TotalValue(matrix,rows,columns)[1]<num-matrix[rows,columns]:
                columns=columns-1
                rows=rows+1
                path=path+"D"

                num=num-matrix[rows,columns]
                continue
            else:
                path=path+"R"
        if abs(Rtotal-num)>abs(Dtotal-num):
            rows=rows+1
            path=path+"D"
            num=num-matrix[rows,columns]
            q=q+1
    return(str(total)+" "+path)


def TotalValue(matrix,rows,columns):
    m0=matrix.shape[0]
    m1=matrix.shape[1]
    i=rows
    j=columns
    if j<m1-1:
        RR=int(0.5*(m0+i+1)*(m0-i)+(m1-j-2)*(i+1))
        DD=int(0.5*(m0+i+1)*(m0-i)-(i+1)+(m1-j-1)*m0)
    if j==m1-1 and i!=m0-1:
        RR=float("inf")
        DD=int(0.5*(m0+i+1)*(m0-i)-(i+1))
    if i==m0-1 and j!=m1-1:
        RR=int((m1-j-1)*(i+1))
        DD=float("inf")
    if i==m0-1 and j==m1-1:
        RR=float("inf")
        DD=float("inf")
    return(RR,DD)


if __name__ == '__main__':

   aa=np.ones([9,9],int)
   for i in range(1,aa.shape[0]):
        aa[i]=aa[i]+i
   sum_a=[65,72,90,110]
   out=str()
   
   for p in range(0,len(sum_a)):
       out=out+DirectTo(aa,sum_a[p])+"\m1"
   bb=np.ones([90000,100000],int)

   for i in range(1,bb.shape[0]):
        bb[i]=bb[i]+i
   sum_b=[87127231192,5994891682]
   
   for k2 in range(0,len(sum_b)):
       if k2==0:
           out=out+"\m1"+DirectTo(bb,sum_b[k2])+"\m1"
       else:
           out=out+DirectTo(bb,sum_b[k2])+"\m1"

   with open('output_question_1','w') as f0:
       f0.write(out)