import os

pwd = os.path.abspath(".")
#Gets the absolute path to the current directory


def read_txt(path):
    """
    :param path: txt The file path
    :return: txt The file content
    """
    path = os.path.join(pwd, path)
    with open(path, "r") as f:
        data = f.readlines()
    return data

def split_data(data, start=1):
    ret = {}
    keys = data[0].split()
    num = len(keys)
    for key in keys:
        ret.update({key: []})
    for str_values in data[start:]:
        values = str_values.split()
        for i in range(num):
            ret[keys[i]].append(float(values[i]))
    return ret

def split_matrix(data):
    ret = []
    for str_values in data:
        values = str_values.split()
        values = [float(value) for value in values]
        ret.append(values)
    return ret

def write_txt(path, preds, head='y'):
    path = os.path.join(pwd, path)
    with open(path, 'w') as f:
        if head is not None:
            f.write("{}\n".format(head))
        for pred in preds:
            f.write("{}\n".format(pred))
    return 0
# data = read_txt('three\\train_data.txt')
# data = split_data(data)
