def rayCasting(p, poly):
    px = p['x']
    py = p['y']
    flag = False

    i = 0
    l = len(poly)
    j = l - 1
    # for(i = 0, l = poly.length, j = l - 1; i < l; j = i, i++):
    while i < l:
        sx = poly[i]['x']
        sy = poly[i]['y']
        tx = poly[j]['x']
        ty = poly[j]['y']

        # Point coincides with polygon vertex
        if (sx == px and sy == py) or (tx == px and ty == py):
            return (px, py)

        # Judge whether the two ends of the line segment are on both sides of the ray
        if (sy < py and ty >= py) or (sy >= py and ty < py):
            # The X coordinate of the point on the line segment which is the same as the Y coordinate of the ray
            x = sx + (py - sy) * (tx - sx) / (ty - sy)
            # The point is on the edge of the polygon
            if x == px:
                return (px, py)
            # The ray passes through the boundary of the polygon
            if x > px:
                flag = not flag
        j = i
        i += 1

    # When the number of ray passing through the polygon boundary is odd, the point is in the polygon
    return str(px)+' '+str(py)+' '+'inside' if flag else str(px)+' '+str(py)+' '+'outside'


# get a list(dict) like ['x':x1,'y':y1,...]
def getpoint(a):
    point = []
    for i in range(0,len(a)-1,2):
        point.append({'x': float(a[i]), 'y': float(a[i+1])})
    return point



# Judging whether the point is in polygen or not according to the two input
def rs(point, polygen):
    zm = getpoint(point)
    dbx = getpoint(polygen)
    count = 0
    for point in zm:
        rs = rayCasting(point, dbx)
        f.write('\n'+rs)


f=open(r'input_question_6_polygon','r')
source = f.read()
f.close()
polygen=list(map(int,source.split())) #to generate a polygen list like[x1,y1,x2,y2...]
f=open(r'input_question_6_points','r')
source = f.read()
f.close()
point=list(map(int,source.split())) #to generate a point list like[x1,y1,x2,y2...]
f=open(r'output_question_6','a')
rs(point,polygen)
