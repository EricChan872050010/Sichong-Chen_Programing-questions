# -*- coding: utf-8 -*-
"""
Created on Tue Feb  9 17:20:59 2021

"""
import numpy as np

global colors,ctc,penalty

####################
#Enter data here

colors = ['R', 'B']
ctc = [12,13]
N = 5

#colors = ['R', 'B', 'G', 'W', 'Y']
#ctc = [139,1451,977,1072,457]  #corresponds to the amount of each color
#N = 64       #corresponds to the order

grid =  [[0 for i in range(N+1)] for i in range(N+1)]
#####################

penalty = 0

def switchColor(i1, i2):
    global colors,ctc
    temp1 = colors[i1]
    colors[i1] = colors[i2]
    colors[i2] = temp1

    temp2 = ctc[i1]
    ctc[i1] = ctc[i2]
    ctc[i2] = temp2
    

def reSortColor(c):
    for i in range(len(colors)):
        if colors[i] == c:
            j = i 
            for i in range(i, len(colors)-1):
                if (ctc[j] < ctc[j+1]):
                    switchColor(j,j+1)
            
                

        

def fillGrid(x, y):
    global penalty
    
    if len(ctc) > 2:
        if (ctc[2] > 0):
            for i in range(2):
                if(colors[i]!=grid[x-1][y] and colors[i]!=grid[x][y-1]):
                    grid[x][y] = colors[i]
                    ctc[i] = ctc[i] - 1
                    reSortColor(colors[i])
                    return grid[x][y]
                
            grid[x][y] = colors[2]
            ctc[2] = ctc[2] - 1
            reSortColor(colors[2])
            return grid[x][y]
        
        elif(ctc[2]==0 and ctc[1]>0):
            for i in range(2):
                if(colors[i]!=grid[x-1][y] and colors[i]!=grid[x][y-1]):
                    grid[x][y] = colors[i]
                    ctc[i] = ctc[i] - 1
                    reSortColor(colors[i])
                    return grid[x][y]
                
            grid[x][y] = colors[1]
            ctc[1] = ctc[1] - 1
            
            if(grid[x][y] == grid[x-1][y]) :
                penalty += 1
            if(grid[x][y] == grid[x][y-1]) :
                penalty += 1
                
            return grid[x][y]
        
        elif(ctc[0]>0 and ctc[1]==0):
            grid[x][y] = colors[0]
            ctc[0] = ctc[0] - 1
            if(grid[x][y] == grid[x-1][y]) :
                penalty += 1
            if(grid[x][y] == grid[x][y-1]) :
                penalty += 1
            return grid[x][y]
        
    elif(ctc[1]>0):
        for i in range(2):
            if(colors[i]!=grid[x-1][y] and colors[i]!=grid[x][y-1]):
                grid[x][y] = colors[i]
                ctc[i] = ctc[i] - 1
                reSortColor(colors[i])
                return grid[x][y]
            
        grid[x][y] = colors[1]
        ctc[1] = ctc[1] - 1
        if(grid[x][y] == grid[x-1][y]) :
            penalty += 1
        if(grid[x][y] == grid[x][y-1]) :
            penalty += 1
        return grid[x][y]
        
    elif(ctc[0]>0 and ctc[1]==0):
        grid[x][y] = colors[0]
        ctc[0] = ctc[0] - 1
        if(grid[x][y] == grid[x-1][y]) :
            penalty += 1
        if(grid[x][y] == grid[x][y-1]) :
            penalty += 1
        return grid[x][y]

if __name__ == '__main__':
    
    #Sort the raw data
    sort_index = np.argsort(np.array(ctc))[::-1]
    temp1 = colors
    temp2 = ctc
    colors = []
    ctc = []
    for i in list(sort_index):
        colors.append(temp1[i])
        ctc.append(temp2[i])
    
    
    #The first row and first column are assigned a value of 0 to facilitate the calculation of the penalty value
    #Just remove this row and this column when outputting
    L = len(grid)
    for i in range(L):
        grid[0][i] = '0'
        grid[i][0] = '0'
    
    #fill the grid
    for i in range(1,L):
        for j in range(1,L):
            grid[i][j] = fillGrid(i,j)

    #output the gird
    for i in range(N):
        for j in range(N):
            print(grid[i+1][j+1], end ='')
        print("\n")











