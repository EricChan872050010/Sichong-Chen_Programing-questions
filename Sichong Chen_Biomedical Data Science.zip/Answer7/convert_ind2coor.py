import utils
import numpy as np


def convert(L, index):
    index = int(index)
    L = L[::-1]
    dims = len(L)
    coor = np.zeros((dims, ), dtype=int)
    for i in range(1, dims):
        L[dims - 1 - i] *= L[dims - i]
    for j in range(dims - 1):
        coor[j] = index // L[j + 1]
        index = index % L[j + 1]
    coor[-1] = index
    return coor[::-1]

def convert_file(L, data_path, save_path):
    data = utils.read_txt(data_path)
    data = utils.split_data(data)
    key = list(data.keys())[0]
    coors = []
    heads = []
    for i in range(len(L)):
        heads.append("x{}".format(i + 1))
    head = "\t".join(heads)
    for index in data[key]:
        coor = convert(L, index).tolist()
        coor_str = [str(num) for num in coor]
        coor_str = "\t".join(coor_str)
        coors.append(coor_str)
    utils.write_txt(save_path, coors, head=head)
    return 0


if __name__ == "__main__":
    convert_file([50, 57], 'input_index_7_1.txt', ' output_coordinates_7_1.txt')
    convert_file([4, 8, 5, 9, 6, 7], 'input_index_7_2.txt', ' output_coordinates_7_2.txt')

