//---------------Input file1: input_coordinates_7_2.txt---------------//

1st column: x1
2nd column: x2
.
.
.
6th column: x6

//---------------Output file1: output_index_7_2.txt---------------//

1st column: index

**NOTE**
Refer to "output_index_7_2_example.txt"


//---------------Input file2: input_index_7_2.txt---------------//

1st column: index

//---------------Output file2: output_coordinates_7_2.txt---------------//

1st column: x1
2nd column: x2
.
.
.
6th column: x6

**NOTE**
Refer to "output_coordinates_7_2_example.txt"


