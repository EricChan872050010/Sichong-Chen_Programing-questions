import utils
import numpy as np


def convert(L, coor):
    L = L[::-1]
    coor = coor[::-1]
    dims = len(L)
    for i in range(1, dims):
        L[dims - 1 - i] *= L[dims - i]
    index = 0
    for j in range(dims - 1):
        index += L[j + 1] * coor[j]
    index += coor[-1]
    return int(index)


def convert_file(L, data_path, save_path):
    data = utils.read_txt(data_path)
    data = utils.split_data(data)
    keys = data.keys()
    indexes = []
    head = "index"
    for i in range(len(data['x1'])):
        coor = []
        for key in keys:
            coor.append(data[key][i])
        index = convert(L, coor)
        indexes.append(str(index))
    utils.write_txt(save_path, indexes, head=head)
    return 0


if __name__ == "__main__":
    convert_file([50, 57], 'input_coordinates_7_1.txt', ' output_index_7_1.txt')
    convert_file([4, 8, 5, 9, 6, 7], 'input_coordinates_7_2.txt', ' output_index_7_2.txt')

